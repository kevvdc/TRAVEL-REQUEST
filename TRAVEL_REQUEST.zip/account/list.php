<?php
require_once "../classes/staff.php";
session_start();

if (!isset($_SESSION["user"])) {
    header("Location: ../account/login.php");
    exit();
}

if (!isset($_SESSION["user"]["role"]) || strcasecmp($_SESSION["user"]["role"], "Admin") !== 0) {
    die("Access Denied.");
}

$staffObj = new Staff();

$search = $role = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $search = isset($_GET["search"]) ? trim(htmlspecialchars($_GET["search"])) : "";
    $role = isset($_GET["role"]) ? trim(htmlspecialchars($_GET["role"])) : "";
}

$staffList = $staffObj->viewStaff($search, $role);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="styles/list.css">
<title>Staff List</title>
</head>
<body>
<h1>Staff List</h1>

<form action="" method="get">
    <label for="search">Search</label>
    <input type="text" name="search" id="search" value="<?= $search ?>" placeholder="Name or Email">

    <select name="role" id="role">
        <option value="">--All Roles--</option>
        <option value="Admin" <?= ($role == "Admin") ? "selected" : ""; ?>>Admin</option>
        <option value="Staff" <?= ($role == "Staff") ? "selected" : ""; ?>>Staff</option>
    </select>
    <input type="submit" value="Search">
    <?php if (!empty($search) || !empty($role)) : ?>
        <a href="<?= $_SERVER['PHP_SELF'] ?>" id="clear">X</a>
    <?php endif; ?>
</form>

<br><br>

<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>No.</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
        <th>Role</th>
        <th>Active</th>
        <th>Option</th>
    </tr>

    <?php
    $counter = 1;
    $hasData = false;

    if ($staffList) {
        foreach ($staffList as $staff) {
            if (!empty($search) && stripos($staff["firstname"], $search) === false &&
                stripos($staff["lastname"], $search) === false &&
                stripos($staff["email"], $search) === false) continue;

            if (!empty($role) && $staff["role"] != $role) continue;

            $hasData = true;
            $fullName = htmlspecialchars($staff["firstname"] . " " . $staff["lastname"]);
            $message = "Are you sure you want to delete $fullName?";
    ?>
            <tr>
                <td><?= $counter++ ?></td>
                <td><?= htmlspecialchars($staff["firstname"]) ?></td>
                <td><?= htmlspecialchars($staff["lastname"]) ?></td>
                <td><?= htmlspecialchars($staff["email"]) ?></td>
                <td><?= htmlspecialchars($staff["role"]) ?></td>
                <td><?= $staff["is_active"] ? "Yes" : "No" ?></td>
                <td>
                    <a href="editstaff.php?id=<?= $staff["id"] ?>">Edit</a> |
                    <a href="deletestaff.php?id=<?= $staff['id'] ?>" onclick="return confirm('<?= $message ?>')">Delete</a>
                </td>
            </tr>
    <?php
        }
    }

    if (!$hasData) {
        echo "<tr><td colspan='7'>No staff found.</td></tr>";
    }
    ?>
</table>

<div class="button-container">
<a href="register.php">Register Staff</a>
<a href="../admin_dashboard.php">Back to Dashboard</a>
<a href="logout.php">Logout</a>
</div>


</body>
</html>
