<?php
session_start();
require_once "../classes/staff.php";
require_once "../classes/email_verification.php";

$staffObj = new Staff();
$conn = $staffObj->connect();
$emailVerifier = new EmailVerification();

$error = "";
$success = "";

// ------------------------------
// Ensure session exists
// ------------------------------
if (!isset($_SESSION["verification"]) || !isset($_SESSION["email"])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION["email"];

// ------------------------------
// Handle form submission
// ------------------------------
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $enteredPin = trim($_POST["pin"]);

    // Validate PIN format
    if (!preg_match('/^\d{6}$/', $enteredPin)) {
        $error = "PIN must be exactly 6 digits.";
    } else {
        // Check if this is a new registration (pending_staff exists) or existing account verification
        if (isset($_SESSION['pending_staff'])) {
            // NEW REGISTRATION - Verify PIN from session
            $pendingStaff = $_SESSION['pending_staff'];
            $sessionPin = $pendingStaff['pin_code'];
            $pinExpiry = $pendingStaff['pin_expiry'];
            
            if ($sessionPin !== $enteredPin) {
                $error = "Invalid PIN code.";
            } elseif (strtotime($pinExpiry) < time()) {
                $error = "PIN has expired. Please request a new one.";
            } else {
                // PIN verified successfully - now add staff to database
                $staffObj->firstname = $pendingStaff['firstname'];
                $staffObj->lastname = $pendingStaff['lastname'];
                $staffObj->role = $pendingStaff['role'];
                $staffObj->email = $pendingStaff['email'];
                $staffObj->password = $pendingStaff['password'];
                $staffObj->is_active = 1; // Activate the account immediately
                
                if ($staffObj->addStaff()) {
                    // Clear pending staff data from session
                    unset($_SESSION['pending_staff']);
                    unset($_SESSION['verification']);
                    unset($_SESSION['email']);
                    
                    $success = "Staff registered and email verified successfully!";
                } else {
                    $error = "Failed to register staff. Please contact administrator.";
                }
            }
        } else {
            // EXISTING ACCOUNT - Verify PIN from database
            $stmt = $conn->prepare("SELECT verification_pin, pin_expiry, is_active FROM staff WHERE email = :email LIMIT 1");
            $stmt->execute([":email" => $email]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$row) {
                $error = "Account not found.";
            } elseif ($row["is_active"] == 1) {
                $success = "This account is already verified.";
            } else {
                // Compare PINs as strings, trim to avoid whitespace issues
                $dbPin = trim((string)$row["verification_pin"]);
                if ($dbPin !== $enteredPin) {
                    $error = "Invalid PIN code.";
                } elseif (strtotime($row["pin_expiry"]) < time()) {
                    $error = "PIN has expired. Please request a new one.";
                } else {
                    // Activate account
                    $update = $conn->prepare("
                        UPDATE staff
                        SET is_active = 1,
                            verification_pin = NULL,
                            pin_expiry = NULL
                        WHERE email = :email
                    ");
                    $update->execute([":email" => $email]);

                    // Clear verification session
                    unset($_SESSION["verification"]);
                    unset($_SESSION["email"]);

                    $success = "Email verified successfully!";
                }
            }
        }
    }
}

// ------------------------------
// Resend PIN
// ------------------------------
if (isset($_GET["resend"]) && $_GET["resend"] == 1) {
    $newPin = "";
    
    // Check if this is for pending registration or existing account
    if (isset($_SESSION['pending_staff'])) {
        // For pending registration
        $pendingStaff = $_SESSION['pending_staff'];
        $fullName = $pendingStaff['firstname'] . ' ' . $pendingStaff['lastname'];
        
        try {
            $emailVerifier->verifyEmail($email, $fullName, $newPin);
            
            // Update PIN in session
            $_SESSION['pending_staff']['pin_code'] = $newPin;
            $_SESSION['pending_staff']['pin_expiry'] = date('Y-m-d H:i:s', strtotime('+10 minutes'));
            
            $success = "A new PIN has been sent to your email.";
        } catch (Exception $e) {
            $error = "Failed to resend PIN: " . $e->getMessage();
        }
    } else {
        // For existing account
        try {
            $emailVerifier->verifyEmail($email, $email, $newPin);

            // Update PIN + expiry in DB
            $stmt = $conn->prepare("
                UPDATE staff
                SET verification_pin = :pin,
                    pin_expiry = DATE_ADD(NOW(), INTERVAL 10 MINUTE)
                WHERE email = :email
            ");
            $stmt->execute([":pin" => $newPin, ":email" => $email]);

            $success = "A new PIN has been sent to your email.";
        } catch (Exception $e) {
            $error = "Failed to resend PIN: " . $e->getMessage();
        }
    }
}

// ------------------------------
// Early return on success
// ------------------------------
if ($success && !isset($_GET["resend"])) {
    echo "
    <!DOCTYPE html>
    <html>
    <head>
        <title>Verified</title>
        <style>
            body { font-family: Arial; padding: 40px; text-align: center; }
            .success { color: green; font-size: 20px; margin-bottom: 20px; }
            a { 
                display: inline-block;
                background: #8B0000;
                color: white;
                padding: 12px 24px;
                text-decoration: none;
                border-radius: 5px;
                font-size: 16px;
                margin-top: 20px;
            }
            a:hover { background: #6d0000; }
        </style>
    </head>
    <body>
        <p class='success'>{$success}</p>
        <a href='list.php'>Go to Staff Management</a>
    </body>
    </html>
    ";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verify PIN</title>
    <link rel="stylesheet" href="styles/form.css">
    <style>
        .error { color: red; margin: 10px 0; }
        .success { color: green; margin: 10px 0; }
        input { width: 100%; padding: 10px; margin-top: 10px; }
        .form-card { max-width: 400px; margin: auto; }
        .links { margin-top: 15px; text-align: center; }
    </style>
</head>
<body>
<div class="form-card">
    <h1>Email Verification</h1>
    <p>Enter the 6-digit PIN sent to <strong><?= htmlspecialchars($email) ?></strong></p>

    <?php if ($error): ?>
        <p class="error"><?= $error ?></p>
    <?php elseif ($success && isset($_GET["resend"])): ?>
        <p class="success"><?= $success ?></p>
    <?php endif; ?>

    <form method="POST">
        <label for="pin">Verification PIN</label>
        <input type="text" maxlength="6" name="pin" id="pin" required pattern="\d{6}" title="Enter 6 digits">
        <br><br>
        <input type="submit" value="Verify">
    </form>

    <div class="links">
        <a href="register.php">Go back</a> |
        <a href="?resend=1">Resend PIN</a>
    </div>
</div>
</body>
</html>