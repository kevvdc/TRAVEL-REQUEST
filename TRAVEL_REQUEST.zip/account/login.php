<?php 
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

require_once "../classes/account.php";
$account = new Account();

$loginData = [
    "email" => "",
    "password" => ""
];

$errors = [
    "email" => "",
    "password" => "",
    "general" => ""
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loginData["email"] = trim(htmlspecialchars($_POST["email"]));
    $loginData["password"] = trim(htmlspecialchars($_POST["password"]));

    if (empty($loginData["email"])) $errors["email"] = "Email is required.";
    if (empty($loginData["password"])) $errors["password"] = "Password is required.";

    if (empty(array_filter($errors))) {
        $account->email = $loginData["email"];
        $account->password = $loginData["password"];

        if ($account->login()) {

            // Fetch user info
            $sql = "SELECT * FROM staff WHERE email = :email LIMIT 1";
            $query = $account->connect()->prepare($sql);
            $query->bindParam(":email", $account->email);
            $query->execute();
            $userData = $query->fetch(PDO::FETCH_ASSOC);

            if ($userData) {

                // Store session
                $_SESSION["user"] = [
                    'staff_id'  => $userData['id'] ?? $userData['staff_id'] ?? null,
                    'firstname' => $userData['firstname'],
                    'lastname'  => $userData['lastname'],
                    'role'      => strtolower($userData['role']), // ensure lowercase
                    'email'     => $userData['email']
                ];

                // REDIRECT BASED ON ROLE
                if ($_SESSION["user"]["role"] === "admin") {
                    header("Location: ../admin_dashboard.php");
                } else {
                    header("Location: ../dashboard.php"); // STAFF DASHBOARD
                }
                exit;
            } 
            else {
                $errors["general"] = "Failed to retrieve user data.";
            }
        } else {
            $errors["general"] = "Invalid email or password. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Travel Request System</title>
    <link rel="stylesheet" href="styles/login.css">
</head>
<body>
    <h1>Travel Request Login</h1>

    <?php if ($errors["general"]) : ?>
        <div class="general-error"><?= $errors["general"] ?></div>
    <?php endif; ?>

    <div class="login-card">
        <label>Fields with <span>*</span> are required</label>

        <form method="post" action="">
            <label>Email <span>*</span></label>
            <input type="text" name="email" value="<?= htmlspecialchars($loginData['email']) ?>">
            <p class="error"><?= $errors['email'] ?></p>

            <label>Password <span>*</span></label>
            <input type="password" name="password">
            <p class="error"><?= $errors['password'] ?></p>

            <button type="submit" name="login">Login</button>
        </form>
    </div>
</body>
</html>
