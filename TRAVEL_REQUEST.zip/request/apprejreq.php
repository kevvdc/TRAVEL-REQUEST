<?php
session_start();

require_once "../classes/travelrequest.php";
require_once "../classes/email_notifications.php";

$travelObj = new TravelRequest();
$emailObj  = new EmailNotifications();
$message   = "";

// Get admin ID
$admin_id = $_SESSION['user']['id'] ?? null;

/* ============================
   Handle Actions
============================ */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"], $_POST["id"])) {
    $id     = (int) $_POST["id"];
    $action = $_POST["action"];

    if ($action === "approve") {
        $ok = $travelObj->approveRequest($id, $admin_id);
        $message = $ok ? "The request has been approved." : "Failed to approve the request.";

        if ($ok) {
            $conn = $travelObj->connect();
            $stmt = $conn->prepare("
                SELECT s.email, s.firstname, s.lastname,
                       tr.destination_venue, tr.destination_city, tr.destination_country
                FROM staff s
                JOIN travelrequests tr ON s.id = tr.staff_id
                WHERE tr.request_id = :id
            ");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            $reqData = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($reqData) {
                $staffName  = $reqData['firstname'] . ' ' . $reqData['lastname'];
                $destination = $reqData['destination_venue'] . ', ' .
                               $reqData['destination_city'] . ', ' .
                               $reqData['destination_country'];
                $emailObj->sendStatusUpdateEmail(
                    $reqData['email'],
                    $staffName,
                    $destination,
                    'Approved'
                );
            }
        }
    }

    if ($action === "reject") {
        $reason = trim($_POST["rejection_reason"]);
        $ok = $travelObj->rejectRequest($id, $admin_id, $reason);
        $message = $ok ? "The request has been rejected." : "Failed to reject the request.";
    }

    if ($action === "undo") {
        $ok = $travelObj->undoRequest($id, $admin_id);
        $message = $ok ? "The request has been reverted to pending." : "Failed to revert the request.";
    }

    if ($action === "delete") {
        $ok = $travelObj->deleteRequest($id, $admin_id);
        $message = $ok ? "The request has been deleted." : "Failed to delete the request.";
    }
}

/* ============================
   Search Filters
============================ */
$search = $_GET["search"] ?? "";
$status = $_GET["status"] ?? "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Travel Requests Management</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles/apprejreq.css?v=3">
</head>

<body>

<h1>Travel Requests Management</h1>

<form method="get">
    <label>Search</label>
    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Staff or destination">

    <label>Status</label>
    <select name="status">
        <option value="">-- All --</option>
        <option value="Pending"  <?= $status=="Pending"  ? "selected" : "" ?>>Pending</option>
        <option value="Approved" <?= $status=="Approved" ? "selected" : "" ?>>Approved</option>
        <option value="Rejected" <?= $status=="Rejected" ? "selected" : "" ?>>Rejected</option>
    </select>

    <input type="submit" value="Search">
    <?php if ($search || $status): ?>
        <a href="<?= $_SERVER['PHP_SELF'] ?>" id="clear">x</a>
    <?php endif; ?>
</form>

<?php if ($message): ?>
    <div class="message"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<div class="cards-container">

<?php
$counter = 1;
$hasData = false;
$conn = $travelObj->connect();

foreach ($travelObj->viewRequests(null, $status) as $req) {

    $fullName = $req["firstname"] . " " . $req["lastname"];
    $destination = $req["destination_venue"] . ", " .
                   $req["destination_city"] . ", " .
                   $req["destination_country"];

    if ($search &&
        stripos($fullName, $search) === false &&
        stripos($destination, $search) === false) {
        continue;
    }

    $hasData = true;

    $statusClass = strtolower($req["status"]);

    $costStmt = $conn->prepare("SELECT cost_allocation, cost FROM costs WHERE request_id = :id");
    $costStmt->bindParam(":id", $req["request_id"]);
    $costStmt->execute();
    $costs = $costStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="request-card">

    <div class="card-header">
        <div class="card-number"><?= $counter ?></div>
        <div class="card-status status-<?= $statusClass ?>">
            <?= htmlspecialchars($req["status"]) ?>
        </div>
    </div>

    <div class="card-body">

        <div class="card-field">
            <div class="card-label">Staff Name</div>
            <div class="card-value staff-name"><?= htmlspecialchars($fullName) ?></div>
        </div>

        <div class="card-field">
            <div class="card-label">Destination</div>
            <div class="card-value"><?= htmlspecialchars($destination) ?></div>
        </div>

        <div class="card-field">
            <div class="card-label">Travel Dates</div>
            <div class="card-value">
                <?= htmlspecialchars($req["travel_start_date"]) ?> →
                <?= htmlspecialchars($req["travel_end_date"]) ?>
            </div>
        </div>

        <div class="card-field">
            <div class="card-label">Purpose</div>
            <div class="card-value"><?= htmlspecialchars($req["purpose"]) ?></div>
        </div>

        <div class="card-field">
            <div class="card-label">Estimated Cost</div>
            <div class="card-value cost"><?= number_format($req["estimated_cost"], 2) ?></div>
        </div>

        <div class="card-field">
            <div class="card-label">Cost Breakdown</div>
            <div class="cost-breakdown">
                <?php if ($costs): ?>
                    <?php foreach ($costs as $c): ?>
                        <div class="cost-breakdown-item">
                            <span><?= htmlspecialchars($c["cost_allocation"]) ?></span>
                            <strong><?= number_format($c["cost"], 2) ?></strong>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    No breakdown available
                <?php endif; ?>
            </div>
        </div>

        <?php if ($req["status"] === "Rejected" && $req["rejection_reason"]): ?>
            <div class="rejection-reason">
                <?= htmlspecialchars($req["rejection_reason"]) ?>
            </div>
        <?php endif; ?>

    </div>

    <div class="card-actions">

        <?php if ($req["status"] === "Pending"): ?>

            <form method="post" onsubmit="return confirm('Approve this request?');">
                <input type="hidden" name="id" value="<?= $req["request_id"] ?>">
                <input type="hidden" name="action" value="approve">
                <button class="btn-approve">Approve</button>
            </form>

            <form method="post" onsubmit="return confirm('Reject this request?');">
                <input type="hidden" name="id" value="<?= $req["request_id"] ?>">
                <input type="hidden" name="action" value="reject">
                <input type="text" name="rejection_reason" placeholder="Reason" required>
                <button class="btn-reject">Reject</button>
            </form>

        <?php else: ?>

            <form method="post" onsubmit="return confirm('Undo this request?');">
                <input type="hidden" name="id" value="<?= $req["request_id"] ?>">
                <input type="hidden" name="action" value="undo">
                <button class="btn-undo">Undo</button>
            </form>

            <?php if ($req["status"] === "Rejected"): ?>
                <form method="post" onsubmit="return confirm('Delete this request?');">
                    <input type="hidden" name="id" value="<?= $req["request_id"] ?>">
                    <input type="hidden" name="action" value="delete">
                    <button class="btn-delete">Delete</button>
                </form>
            <?php endif; ?>

        <?php endif; ?>

        <form action="print_pdf.php" method="get" target="_blank">
            <input type="hidden" name="id" value="<?= $req["request_id"] ?>">
            <button class="btn-print">Print</button>
        </form>

    </div>

</div>

<?php
$counter++;
}
?>

</div>

<?php if (!$hasData): ?>
    <div class="no-results">
        <p>No travel requests found.</p>
    </div>
<?php endif; ?>

<div class="button-container">
    <a href="../admin_dashboard.php" class="btn">Back to Dashboard</a>
    <a href="../account/logout.php" class="btn">Logout</a>
</div>

</body>
</html>
