<?php 
require_once "../classes/travelrequest.php";
session_start();

$travelObj = new TravelRequest();

if (!isset($_SESSION["user"]) || empty($_SESSION["user"]["staff_id"])) {
    die("Session expired. Please log in again.");
}
$staff_id = $_SESSION["user"]["staff_id"];

$search = $status = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $search = isset($_GET["destination"]) ? trim(htmlspecialchars($_GET["destination"])) : "";
    $status = isset($_GET["status"]) ? trim(htmlspecialchars($_GET["status"])) : "";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>My Travel Requests</title>
    <link rel="stylesheet" href="styles/view.css?v=3" />
</head>
<body>

<h1>My Travel Requests</h1>

<form action="" method="get">
    <label>Search Destination</label>
    <input type="text" name="destination" value="<?= $search ?>" placeholder="Destination" />

    <label>Status</label>
    <select name="status">
        <option value="">-- All --</option>
        <option value="Pending"  <?= ($status=="Pending")?"selected":""; ?>>Pending</option>
        <option value="Approved" <?= ($status=="Approved")?"selected":""; ?>>Approved</option>
        <option value="Rejected" <?= ($status=="Rejected")?"selected":""; ?>>Rejected</option>
    </select>

    <input type="submit" value="Search" />
    <?php if (!empty($search) || !empty($status)) : ?>
        <a href="<?= $_SERVER['PHP_SELF'] ?>" id="clear">x</a>
    <?php endif; ?>
</form>

<div class="cards-container">

<?php
$counter = 1;
$hasData = false;
$conn = $travelObj->connect();

$requests = $travelObj->viewRequests($staff_id, $status);

foreach ($requests as $req) {
    if ($req["status"] == "Deleted") continue;

    $destination = htmlspecialchars($req["destination_venue"]) . ", " .
                   htmlspecialchars($req["destination_city"]) . ", " .
                   htmlspecialchars($req["destination_country"]);

    if (!empty($search) && stripos($destination, $search) === false) continue;

    $hasData = true;
    $statusClass = strtolower($req["status"]);

    $costStmt = $conn->prepare("SELECT cost_allocation, cost FROM costs WHERE request_id = :rid");
    $costStmt->bindParam(":rid", $req["request_id"]);
    $costStmt->execute();
    $costs = $costStmt->fetchAll(PDO::FETCH_ASSOC);

    $message = "Do you wish to delete the travel request to " . $destination . "?";
?>

<div class="request-card">

    <div class="card-header">
        <div class="card-number"><?= $counter++ ?></div>
        <div class="card-status status-<?= $statusClass ?>">
            <?= htmlspecialchars($req["status"]) ?>
        </div>
    </div>

    <div class="card-body">

        <div class="card-field">
            <div class="card-label">Destination</div>
            <div class="card-value"><?= $destination ?></div>
        </div>

        <div class="card-field">
            <div class="card-label">Travel Dates</div>
            <div class="card-value">
                <?= htmlspecialchars($req["travel_start_date"]) ?> →
                <?= htmlspecialchars($req["travel_end_date"]) ?>
            </div>
        </div>

        <div class="card-field">
            <div class="card-label">Purpose</div>
            <div class="card-value"><?= htmlspecialchars($req["purpose"]) ?></div>
        </div>

        <div class="card-field">
            <div class="card-label">Estimated Cost</div>
            <div class="card-value cost"><?= number_format($req["estimated_cost"],2) ?></div>
        </div>

        <div class="card-field">
            <div class="card-label">Cost Breakdown</div>
            <div class="cost-breakdown">
                <?php if ($costs): foreach ($costs as $c): ?>
                    <div class="cost-breakdown-item">
                        <span><?= htmlspecialchars($c["cost_allocation"]) ?></span>
                        <strong><?= number_format($c["cost"],2) ?></strong>
                    </div>
                <?php endforeach; else: ?>
                    No breakdown available
                <?php endif; ?>
            </div>
        </div>

        <?php if ($req["status"]=="Rejected" && !empty($req["rejection_reason"])): ?>
            <div class="rejection-reason">
                <?= htmlspecialchars($req["rejection_reason"]) ?>
            </div>
        <?php endif; ?>

    </div>

    <div class="card-actions">

        <?php if ($req["status"]=="Pending"): ?>
            <a class="btn-undo" href="editreqs.php?id=<?= $req["request_id"] ?>">Edit</a>
            <a class="btn-delete" href="deletereqs.php?id=<?= $req["request_id"] ?>" onclick="return confirm('<?= $message ?>')">Delete</a>
        <?php elseif ($req["status"]=="Rejected"): ?>
            <a class="btn-delete" href="deletereqs.php?id=<?= $req["request_id"] ?>" onclick="return confirm('<?= $message ?>')">Delete</a>
        <?php endif; ?>

        <a class="btn-print" href="print_pdf.php?id=<?= $req["request_id"] ?>" target="_blank">Print</a>

    </div>
</div>

<?php }
if (!$hasData): ?>
    <div class="no-results">No travel requests found.</div>
<?php endif; ?>

</div>

<div class="button-container">
    <a href="addreqs.php" class="btn">Add Travel Request</a>
    <a href="../dashboard.php" class="btn">Back to Dashboard</a>
    <a href="../account/logout.php" class="btn">Logout</a>
</div>

</body>
</html>