<?php
require_once "../../classes/travelrequest.php"; 
session_start();

// --------------- SESSION CHECK ---------------
if (!isset($_SESSION["user"])) die("Access denied.");
if (!isset($_SESSION["user"]["role"]) || strtolower($_SESSION["user"]["role"]) !== "staff") die("Access denied.");
if (!isset($_SESSION["user"]["staff_id"])) die("Access denied.");

$staff_id = $_SESSION["user"]["staff_id"];
$travelObj = new TravelRequest();

// --------------- HANDLE DELETION ---------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $travelObj->deleteNotification($_POST['delete_id']);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// --------------- GET NOTIFICATIONS FOR STAFF ---------------
$notifications = $travelObj->getStaffNotifications($staff_id);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Notifications</title>
    <link rel="stylesheet" href="notif.css">
</head>
<body>
    <div class="container">
        <h2>Your Notifications</h2>

        <?php if (empty($notifications)) : ?>
            <p>No notifications.</p>
        <?php else : ?>
            <ul>
                <?php foreach ($notifications as $n) : ?>
                    <li>
                        <?= htmlspecialchars($n['message']) ?><br>
                        <strong>Destination:</strong> <?= htmlspecialchars($n['destination_venue']) ?><br>
                        <strong>Status:</strong> <?= htmlspecialchars($n['status']) ?><br>
                        <small>Updated: <?= $n['created_at'] ?></small>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="delete_id" value="<?= $n['id'] ?>">
                            <button type="submit" class="delete-btn">Delete</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>

    <!-- Buttons placed outside the main container -->
    <div class="button-container">
        <a href="../addreqs.php" class="btn">Add Travel Request</a>
        <a href="../../dashboard.php" class="btn">Back to Dashboard</a>
        <a href="../../account/logout.php" class="btn logout">Logout</a>
    </div>
</body>
</html>
