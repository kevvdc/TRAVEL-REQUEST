<?php
require_once "../classes/travelrequest.php";

$reqObj = new TravelRequest();

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET["id"])) {
        $id = trim(htmlspecialchars($_GET["id"]));

        $request = $reqObj->fetchRequest($id);

        if (!$request) {
            echo "<a href='apprejreq.php'>View All Requests Approvals</a>";
            exit("Request not found.");
        } else {

            if ($reqObj->deleteRequest($id)) {
                header("Location: apprejreq.php");
                exit;
            } else {
                echo "An error occurred while deleting the request.";
            }
        }
    } else {
        echo "<a href='apprejreq.php'>View All Requests</a>";
        exit("Invalid request ID.");
    }
}
?>
