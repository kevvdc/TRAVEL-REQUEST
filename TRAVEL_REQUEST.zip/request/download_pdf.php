<?php
require_once "../classes/travelrequest.php";

// Load FPDF library (download from https://www.fpdf.org and put in fpdf186 folder)
require_once "pdf/fpdf.php";

if (!isset($_GET["id"])) {
    die("No request selected.");
}

$request_id = $_GET["id"];

$travel = new TravelRequest();
$data = $travel->fetchRequest($request_id);

if (!$data) {
    die("Request not found.");
}

$costs = $travel->getCosts($request_id);

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont("Arial", "B", 16);
$pdf->Cell(0, 10, "Travel Request Details", 0, 1, "C");

$pdf->SetFont("Arial", "", 12);
$pdf->Ln(5);

$pdf->Cell(50, 8, "Staff Name:", 0, 0);
$pdf->Cell(0, 8, $data['firstname'] . " " . $data['lastname'], 0, 1);

$pdf->Cell(50, 8, "Destination:", 0, 0);
$pdf->Cell(0, 8, $data['destination_venue'] . ", " . $data['destination_city'] . ", " . $data['destination_country'], 0, 1);

$pdf->Cell(50, 8, "Start Date:", 0, 0);
$pdf->Cell(0, 8, $data['travel_start_date'], 0, 1);

$pdf->Cell(50, 8, "End Date:", 0, 0);
$pdf->Cell(0, 8, $data['travel_end_date'], 0, 1);

$pdf->Cell(50, 8, "Purpose:", 0, 0);
$pdf->MultiCell(0, 8, $data['purpose']);

$pdf->Cell(50, 8, "Estimated Cost:", 0, 0);
$pdf->Cell(0, 8, number_format($data['estimated_cost'], 2), 0, 1);

$pdf->Cell(50, 8, "Status:", 0, 0);
$pdf->Cell(0, 8, $data['status'], 0, 1);

$pdf->Ln(5);
$pdf->SetFont("Arial", "B", 14);
$pdf->Cell(0, 10, "Cost Breakdown", 0, 1);

$pdf->SetFont("Arial", "", 12);

if ($costs) {
    foreach ($costs as $c) {
        $pdf->Cell(70, 8, $c['cost_allocation'], 0, 0);
        $pdf->Cell(0, 8, number_format($c['cost'], 2), 0, 1);
    }
} else {
    $pdf->Cell(0, 8, "No cost breakdown available.", 0, 1);
}

$pdf->Output("D", "Travel_Request_{$request_id}.pdf");
exit;
?>
