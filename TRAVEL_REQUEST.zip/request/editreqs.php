<?php
require_once "../classes/travelrequest.php";
session_start();

$reqObj = new TravelRequest();

$request_id = $_GET['id'] ?? null;
if (!$request_id) {
    die("Request ID missing.");
}

$request_data = $reqObj->fetchRequest($request_id);
if (!$request_data) {
    die("Travel request not found.");
}

if ($request_data['staff_id'] != $_SESSION['user']['staff_id']) {
    die("Unauthorized access.");
}

$request = [
    "venue" => $_POST["destination_venue"] ?? $request_data['destination_venue'],
    "city" => $_POST["destination_city"] ?? $request_data['destination_city'],
    "country" => $_POST["destination_country"] ?? $request_data['destination_country'],
    "travel_start_date" => $_POST["travel_start_date"] ?? $request_data['travel_start_date'],
    "travel_end_date" => $_POST["travel_end_date"] ?? $request_data['travel_end_date'],
    "purpose" => $_POST["purpose"] ?? $request_data['purpose']
];

$errors = [
    "venue" => "",
    "city" => "",
    "country" => "",
    "travel_start_date" => "",
    "travel_end_date" => "",
    "purpose" => ""
];

$cost_data = $reqObj->getCosts($request_id);
$cost_allocations = $_POST['cost_allocation'] ?? array_column($cost_data, 'cost_allocation');
$cost_values = $_POST['cost'] ?? array_column($cost_data, 'cost');

if (isset($_POST['add_row'])) {
    $cost_allocations[] = "";
    $cost_values[] = 0;
}
if (isset($_POST['remove_row'])) {
    $index = $_POST['remove_row'];
    unset($cost_allocations[$index], $cost_values[$index]);
    $cost_allocations = array_values($cost_allocations);
    $cost_values = array_values($cost_values);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    if (empty($request["venue"])) $errors["venue"] = "Venue is required.";
    if (empty($request["city"])) $errors["city"] = "City/Province is required.";
    if (empty($request["country"])) $errors["country"] = "Country is required.";
    if (empty($request["travel_start_date"])) $errors["travel_start_date"] = "Start date is required.";
    if (empty($request["travel_end_date"])) $errors["travel_end_date"] = "End date is required.";
    if (!empty($request["travel_start_date"]) && !empty($request["travel_end_date"]) && $request["travel_end_date"] < $request["travel_start_date"])
        $errors["travel_end_date"] = "End date cannot be before start date.";
    if (empty($request["purpose"])) $errors["purpose"] = "Purpose is required.";

    if (empty(array_filter($errors))) {
        $total_cost = 0;
        for ($i = 0; $i < count($cost_allocations); $i++) {
            if (!empty($cost_allocations[$i]) && is_numeric($cost_values[$i])) {
                $total_cost += floatval($cost_values[$i]);
            }
        }

        $reqObj->destination_venue = $request["venue"];
        $reqObj->destination_city = $request["city"];
        $reqObj->destination_country = $request["country"];
        $reqObj->travel_start_date = $request["travel_start_date"];
        $reqObj->travel_end_date = $request["travel_end_date"];
        $reqObj->purpose = $request["purpose"];
        $reqObj->estimated_cost = $total_cost;
        $reqObj->status = "Pending";
        $reqObj->admin_reject_id = null;
        $reqObj->rejection_reason = null;

        if ($reqObj->editRequest($request_id)) {
            $reqObj->deleteCosts($request_id);
            for ($i = 0; $i < count($cost_allocations); $i++) {
                if (!empty($cost_allocations[$i]) && is_numeric($cost_values[$i])) {
                    $reqObj->addCost($request_id, $cost_allocations[$i], $cost_values[$i]);
                }
            }
            header("Location: viewreqs.php");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Travel Request</title>
<link rel="stylesheet" href="styles/form.css">
</head>
<body>
<h1>Edit Travel Request</h1>

<div class="form-card">
<form action="" method="post">
<label for="">Fields with <span>*</span> are required</label>

<label>Destination <span>*</span></label>
<input type="text" name="destination_venue" value="<?= htmlspecialchars($request['venue']) ?>" placeholder="Venue">
<p class="error"><?= $errors['venue'] ?></p>

<input type="text" name="destination_city" value="<?= htmlspecialchars($request['city']) ?>" placeholder="City/Province">
<p class="error"><?= $errors['city'] ?></p>

<input type="text" name="destination_country" value="<?= htmlspecialchars($request['country']) ?>" placeholder="Country">
<p class="error"><?= $errors['country'] ?></p>

<label>Travel Start Date <span>*</span></label>
<input type="date" name="travel_start_date" value="<?= htmlspecialchars($request['travel_start_date']) ?>">
<p class="error"><?= $errors['travel_start_date'] ?></p>

<label>Travel End Date <span>*</span></label>
<input type="date" name="travel_end_date" value="<?= htmlspecialchars($request['travel_end_date']) ?>">
<p class="error"><?= $errors['travel_end_date'] ?></p>

<label>Purpose <span>*</span></label>
<textarea name="purpose"><?= htmlspecialchars($request['purpose']) ?></textarea>
<p class="error"><?= $errors['purpose'] ?></p>

<h3>Cost Breakdown</h3>
<table>
<thead>
<tr>
<th>Cost Allocation</th>
<th>Cost (₱)</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php 
$total_cost = 0;
foreach ($cost_allocations as $i => $alloc) { 
    $cost_val = floatval($cost_values[$i]);
    $total_cost += $cost_val;
?>
<tr>
<td><input type="text" name="cost_allocation[]" value="<?= htmlspecialchars($alloc) ?>"></td>
<td><input type="number" step="0.01" min="0" name="cost[]" value="<?= htmlspecialchars($cost_values[$i]) ?>"></td>
<td><button type="submit" name="remove_row" value="<?= $i ?>">Remove</button></td>
</tr>
<?php } ?>
</tbody>
</table>

<button type="submit" name="add_row">Add Row</button>
<h3>Total Estimated Cost: ₱<?= number_format($total_cost, 2) ?></h3>
<input type="submit" name="submit" value="Update Request">
</form>
</div>

<div class="button-container">
<a href="viewreqs.php" class="btn">View All Requests</a>
<a href="../dashboard.php" class="btn">Back to Dashboard</a>
<a href="logout.php" class="btn">Logout</a>
</div>
</body>
</html>
