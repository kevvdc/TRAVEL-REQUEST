-- SAFE, REPEATABLE SQL SETUP
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `travel_request_db`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE `travel_request_db`;



/* ============================
   STAFF TABLE
   ============================ */
CREATE TABLE IF NOT EXISTS `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(150) NOT NULL,
  `lastname` varchar(150) NOT NULL,
  `role` enum('Staff','Admin') NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/* ============================
   TRAVEL REQUESTS
   ============================ */
CREATE TABLE IF NOT EXISTS `travelrequests` (
  `request_id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `admin_reject_id` int(11) DEFAULT NULL,
  `destination_venue` varchar(100) NOT NULL,
  `destination_city` varchar(100) NOT NULL,
  `destination_country` varchar(100) NOT NULL,
  `travel_start_date` date NOT NULL,
  `travel_end_date` date NOT NULL,
  `purpose` text NOT NULL,
  `estimated_cost` decimal(10,2) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `rejection_reason` text DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `staff_id` (`staff_id`),
  KEY `admin_reject_id` (`admin_reject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




/* ============================
   COST ALLOCATION TABLE
   ============================ */
CREATE TABLE IF NOT EXISTS `costs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `cost_allocation` varchar(255) NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `request_id` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/* ============================
   NOTIFICATIONS TABLE (NEW)
   ============================ */
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `request_id` int(11) DEFAULT NULL,
  `type` enum('NEW_REQUEST','STATUS_UPDATE') NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `request_id` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/* ============================
   FOREIGN KEYS (SAFE)
   ============================ */

ALTER TABLE `travelrequests`
  ADD CONSTRAINT `travelrequests_staff_fk`
    FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `travelrequests`
  ADD CONSTRAINT `travelrequests_admin_fk`
    FOREIGN KEY (`admin_reject_id`) REFERENCES `staff` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `costs`
  ADD CONSTRAINT `costs_request_fk`
    FOREIGN KEY (`request_id`) REFERENCES `travelrequests` (`request_id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_user_fk`
    FOREIGN KEY (`user_id`) REFERENCES `staff` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_request_fk`
    FOREIGN KEY (`request_id`) REFERENCES `travelrequests` (`request_id`)
    ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE staff 
ADD COLUMN verification_pin VARCHAR(6) NULL,
ADD COLUMN pin_expiry DATETIME NULL,
MODIFY COLUMN is_active TINYINT(1) NOT NULL DEFAULT 0;



COMMIT;
