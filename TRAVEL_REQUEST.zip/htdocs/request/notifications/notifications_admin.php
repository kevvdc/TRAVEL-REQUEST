<?php
require_once "../../classes/travelrequest.php"; 
session_start();

// ---------------- SESSION CHECK ----------------
if (!isset($_SESSION["user"])) die("Access denied. Not logged in.");
if (!isset($_SESSION["user"]["role"]) || strtolower($_SESSION["user"]["role"]) !== "admin") die("Access denied. Wrong role.");

$travelObj = new TravelRequest();

// ---------------- HANDLE DELETION ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $travelObj->deleteNotification($_POST['delete_id']);
    header("Location: " . $_SERVER['PHP_SELF']); // refresh page after deletion
    exit;
}

// ---------------- GET ADMIN NOTIFICATIONS ----------------
$notifications = $travelObj->getAdminNotifications();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Notifications</title>
    <link rel="stylesheet" href="notif.css">
</head>
<body>
    <div class="container">
        <h2>Admin Notifications – New Requests</h2>

        <?php if (empty($notifications)) : ?>
            <p>No notifications.</p>
        <?php else : ?>
            <ul>
                <?php foreach ($notifications as $n) : ?>
                    <li>
                        <strong>New Request Submitted:</strong> 
                        <?= htmlspecialchars($n['firstname'] . " " . $n['lastname']) ?><br>
                        <strong>Destination:</strong> <?= htmlspecialchars($n['destination_venue']) ?><br>
                        <small>Submitted: <?= $n['created_at'] ?></small>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="delete_id" value="<?= $n['id'] ?>">
                            <button type="submit" class="delete-btn">Delete</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    
    <div class="button-container">
    <a href="../../admin_dashboard.php" class="btn">Back to Dashboard</a>
    <a href="../../account/logout.php" class="btn">Logout</a>
    </div>
    
</body>
</html>
