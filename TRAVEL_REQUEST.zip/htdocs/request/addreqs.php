<?php 
require_once "../classes/travelrequest.php";
require_once "../classes/email_notifications.php";
session_start();
$reqObj = new TravelRequest();
$emailObj = new EmailNotifications();

$request = [
    "venue" => $_POST["destination_venue"] ?? "",
    "city" => $_POST["destination_city"] ?? "",
    "country" => $_POST["destination_country"] ?? "",
    "travel_start_date" => $_POST["travel_start_date"] ?? "",
    "travel_end_date" => $_POST["travel_end_date"] ?? "",
    "purpose" => $_POST["purpose"] ?? ""
];

$errors = [
    "venue" => "",
    "city" => "",
    "country" => "",
    "travel_start_date" => "",
    "travel_end_date" => "",
    "purpose" => ""
];

$cost_allocations = $_POST['cost_allocation'] ?? [""];
$cost_values = $_POST['cost'] ?? [0];

// Handle add/remove row - but DON'T process the main form
if (isset($_POST['add_row'])) {
    $cost_allocations[] = "";
    $cost_values[] = 0;
}

if (isset($_POST['remove_row'])) {
    $index = $_POST['remove_row'];
    unset($cost_allocations[$index]);
    unset($cost_values[$index]);
    $cost_allocations = array_values($cost_allocations);
    $cost_values = array_values($cost_values);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit']) && !isset($_POST['add_row']) && !isset($_POST['remove_row'])) {
    if (empty($request["venue"])) $errors["venue"] = "Venue is required.";
    if (empty($request["city"])) $errors["city"] = "City/Province is required.";
    if (empty($request["country"])) $errors["country"] = "Country is required.";
    if (empty($request["travel_start_date"])) $errors["travel_start_date"] = "Start date is required.";
    if (empty($request["travel_end_date"])) $errors["travel_end_date"] = "End date is required.";
    if (!empty($request["travel_start_date"]) && !empty($request["travel_end_date"]) && $request["travel_end_date"] < $request["travel_start_date"])
        $errors["travel_end_date"] = "End date cannot be before start date.";
    if (empty($request["purpose"])) $errors["purpose"] = "Purpose is required.";

    if (empty(array_filter($errors))) {
        $total_cost = 0;
        for ($i = 0; $i < count($cost_allocations); $i++) {
            if (!empty($cost_allocations[$i]) && is_numeric($cost_values[$i])) {
                $total_cost += floatval($cost_values[$i]);
            }
        }

        $reqObj->staff_id = $_SESSION['user']['staff_id'];
        $reqObj->destination_venue = $request["venue"];
        $reqObj->destination_city = $request["city"];
        $reqObj->destination_country = $request["country"];
        $reqObj->travel_start_date = $request["travel_start_date"];
        $reqObj->travel_end_date = $request["travel_end_date"];
        $reqObj->purpose = $request["purpose"];
        $reqObj->estimated_cost = $total_cost;
        $reqObj->status = "Pending";

       $request_id = $reqObj->addRequest();
        if ($request_id) {
            for ($i = 0; $i < count($cost_allocations); $i++) {
                if (!empty($cost_allocations[$i]) && is_numeric($cost_values[$i])) {
                    $reqObj->addCost($request_id, $cost_allocations[$i], $cost_values[$i]);
                }
            }
            
            // Send email notification to all admins
            try {
                $conn = $reqObj->connect();
                
                // Get staff info from database using staff_id
                $staffStmt = $conn->prepare("SELECT firstname, lastname FROM staff WHERE id = :sid");
                $staffStmt->bindParam(':sid', $_SESSION['user']['staff_id']);
                $staffStmt->execute();
                $staffData = $staffStmt->fetch(PDO::FETCH_ASSOC);
                
                if ($staffData) {
                    $staffName = $staffData['firstname'] . ' ' . $staffData['lastname'];
                } else {
                    // Fallback to session if available
                    $staffName = ($_SESSION['user']['firstname'] ?? 'Staff') . ' ' . ($_SESSION['user']['lastname'] ?? 'Member');
                }
                
                // Get all admin emails from staff table where role = 'Admin'
                $adminStmt = $conn->prepare("SELECT email, firstname FROM staff WHERE role = 'Admin' AND is_active = 1");
                $adminStmt->execute();
                $adminEmails = $adminStmt->fetchAll(PDO::FETCH_ASSOC);
                
                if ($adminEmails && count($adminEmails) > 0) {
                    $destination = $request["venue"] . ', ' . $request["city"] . ', ' . $request["country"];
                    
                    // Send email to each admin
                    foreach ($adminEmails as $admin) {
                        $emailObj->sendNewRequestEmail(
                            $admin['email'], 
                            $staffName, 
                            $destination, 
                            $request["travel_start_date"], 
                            $request["travel_end_date"], 
                            $request["purpose"], 
                            $total_cost
                        );
                    }
                }
            } catch (Exception $e) {
                // Log error but don't stop the request submission
                error_log("Admin email notification failed: " . $e->getMessage());
            }
            
            header("Location: viewreqs.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Travel Request</title>
<link rel="stylesheet" href="styles/form.css">

<style>
    /* Loading Overlay */
    .loading-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        background: rgba(0, 0, 0, 0.7);
        z-index: 99999;
        overflow: hidden;
    }
    .loading-overlay.active {
        display: flex !important;
        justify-content: center !important;
        align-items: center !important;
    }
    .loading-content {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        position: relative;
        margin: auto;
    }
    .loading-spinner {
        border: 8px solid #f3f3f3;
        border-top: 8px solid #3498db;
        border-radius: 50%;
        width: 60px;
        height: 60px;
        animation: spin 1s linear infinite;
        margin: 0 auto;
    }
    .loading-text {
        color: white;
        font-size: 18px;
        margin-top: 20px;
        text-align: center;
        padding: 0 20px;
        max-width: 90vw;
    }
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
</style>

</head>
<body>

<div class="form-card">
    <h1>Travel Request Form</h1>
    <form action="" method="post">
        <label>Field with <span>*</span> is required</label>

        <label>Destination <span>*</span></label>
        <input type="text" name="destination_venue" value="<?= htmlspecialchars($request['venue']) ?>" placeholder="Venue">
        <p class="error"><?= $errors['venue'] ?></p>

        <input type="text" name="destination_city" value="<?= htmlspecialchars($request['city']) ?>" placeholder="City/Province">
        <p class="error"><?= $errors['city'] ?></p>

        <input type="text" name="destination_country" value="<?= htmlspecialchars($request['country']) ?>" placeholder="Country">
        <p class="error"><?= $errors['country'] ?></p>

        <label>Travel Start Date <span>*</span></label>
        <input type="date" name="travel_start_date" value="<?= htmlspecialchars($request['travel_start_date']) ?>">
        <p class="error"><?= $errors['travel_start_date'] ?></p>

        <label>Travel End Date <span>*</span></label>
        <input type="date" name="travel_end_date" value="<?= htmlspecialchars($request['travel_end_date']) ?>">
        <p class="error"><?= $errors['travel_end_date'] ?></p>

        <label>Purpose <span>*</span></label>
        <textarea name="purpose"><?= htmlspecialchars($request['purpose']) ?></textarea>
        <p class="error"><?= $errors['purpose'] ?></p>

        <h3>Costs</h3>
        <table>
            <thead>
                <tr>
                    <th>Cost Allocation</th>
                    <th>Cost (₱)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $total_cost = 0;
                foreach ($cost_allocations as $i => $alloc) { 
                    $cost_val = floatval($cost_values[$i]);
                    $total_cost += $cost_val;
                ?>
                <tr>
                    <td><input type="text" name="cost_allocation[]" value="<?= htmlspecialchars($alloc) ?>"></td>
                    <td><input type="number" step="0.01" min="0" name="cost[]" value="<?= htmlspecialchars($cost_values[$i]) ?>"></td>
                    <td><button type="submit" name="remove_row" value="<?= $i ?>">Remove</button></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <button type="submit" name="add_row">Add Row</button>

        <h3>Total Estimated Cost: ₱<?= number_format($total_cost, 2) ?></h3>

        <input type="submit" name="submit" value="Submit Request">
    </form>

    <div class="button-container">
        <a href="viewreqs.php" class="btn">View All Requests</a>
        <a href="../dashboard.php" class="btn">Back to Dashboard</a>
        <a href="../account/logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- Loading Overlay -->
<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-content">
        <div class="loading-spinner"></div>
        <div class="loading-text">Processing...<br>Please wait...</div>
    </div>
</div>

<script>
    // Show loading overlay when submitting the main form
    document.querySelector('form').addEventListener('submit', function(e) {
        // Only show loading when submitting the main request (not add/remove row)
        if (e.submitter && e.submitter.name === 'submit') {
            document.getElementById('loadingOverlay').classList.add('active');
        }
    });
</script>

</body>

</html>
