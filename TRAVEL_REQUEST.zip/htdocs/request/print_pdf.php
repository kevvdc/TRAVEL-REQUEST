<?php
require_once "../classes/travelrequest.php";
session_start();

if (!isset($_GET['id'])) {
    die("No request ID provided.");
}

$request_id = intval($_GET['id']);
$travelObj = new TravelRequest();
$conn = $travelObj->connect();

// Get request details
$stmt = $conn->prepare("
    SELECT tr.*, s.firstname, s.lastname, s.email
    FROM travelrequests tr
    JOIN staff s ON tr.staff_id = s.id
    WHERE tr.request_id = :id
");
$stmt->bindParam(':id', $request_id);
$stmt->execute();
$request = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$request) {
    die("Request not found.");
}

// Get cost breakdown
$costStmt = $conn->prepare("SELECT cost_allocation, cost FROM costs WHERE request_id = :id");
$costStmt->bindParam(':id', $request_id);
$costStmt->execute();
$costs = $costStmt->fetchAll(PDO::FETCH_ASSOC);

$staffName = $request['firstname'] . ' ' . $request['lastname'];
$destination = $request['destination_venue'] . ', ' . $request['destination_city'] . ', ' . $request['destination_country'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Travel Request - <?= htmlspecialchars($staffName) ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: white;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px solid #333;
            padding: 30px;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #8B0000;
            padding-bottom: 20px;
        }

        .header h1 {
            color: #8B0000;
            font-size: 28px;
            margin-bottom: 10px;
        }

        .header p {
            color: #666;
            font-size: 14px;
        }

        .section {
            margin-bottom: 25px;
        }

        .section-title {
            background: #8B0000;
            color: white;
            padding: 10px 15px;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .field-group {
            margin-bottom: 15px;
        }

        .field-label {
            font-weight: bold;
            color: #333;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .field-value {
            color: #555;
            font-size: 14px;
            padding: 8px;
            background: #f9f9f9;
            border-left: 3px solid #8B0000;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table th {
            background: #8B0000;
            color: white;
            padding: 10px;
            text-align: left;
            font-size: 14px;
        }

        table td {
            padding: 10px;
            border: 1px solid #ddd;
            font-size: 14px;
        }

        table tr:nth-child(even) {
            background: #f9f9f9;
        }

        .total-row {
            font-weight: bold;
            background: #fff3cd !important;
        }

        .status-badge {
            display: inline-block;
            padding: 8px 15px;
            border-radius: 5px;
            font-weight: bold;
            font-size: 14px;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-approved {
            background: #d4edda;
            color: #155724;
        }

        .status-rejected {
            background: #f8d7da;
            color: #721c24;
        }

        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #ddd;
            text-align: center;
            color: #999;
            font-size: 12px;
        }

        @media print {
            body {
                padding: 0;
            }
            
            .no-print {
                display: none;
            }
            
            .container {
                border: none;
                padding: 0;
            }
        }

        .print-button {
            background: #8B0000;
            color: white;
            border: none;
            padding: 12px 30px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            margin: 20px auto;
            display: block;
        }

        .print-button:hover {
            background: #6d0000;
        }
    </style>
</head>
<body>
    <button class="print-button no-print" onclick="window.print()">🖨️ Print Document</button>

    <div class="container">
        <div class="header">
            <h1>Travel Request Form</h1>
            <p>Request ID: #<?= $request_id ?></p>
            <p>Submitted: <?= date('F d, Y', strtotime($request['submitted_at'])) ?></p>
        </div>

        <div class="section">
            <div class="section-title">Staff Information</div>
            <div class="field-group">
                <div class="field-label">Staff Name:</div>
                <div class="field-value"><?= htmlspecialchars($staffName) ?></div>
            </div>
            <div class="field-group">
                <div class="field-label">Email:</div>
                <div class="field-value"><?= htmlspecialchars($request['email']) ?></div>
            </div>
        </div>

        <div class="section">
            <div class="section-title">Travel Details</div>
            <div class="field-group">
                <div class="field-label">Destination:</div>
                <div class="field-value"><?= htmlspecialchars($destination) ?></div>
            </div>
            <div class="field-group">
                <div class="field-label">Travel Period:</div>
                <div class="field-value">
                    <?= date('F d, Y', strtotime($request['travel_start_date'])) ?> 
                    to 
                    <?= date('F d, Y', strtotime($request['travel_end_date'])) ?>
                </div>
            </div>
            <div class="field-group">
                <div class="field-label">Purpose:</div>
                <div class="field-value"><?= nl2br(htmlspecialchars($request['purpose'])) ?></div>
            </div>
        </div>

        <div class="section">
            <div class="section-title">Cost Breakdown</div>
            <table>
                <thead>
                    <tr>
                        <th>Cost Allocation</th>
                        <th style="text-align: right;">Amount (₱)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($costs): ?>
                        <?php foreach ($costs as $cost): ?>
                            <tr>
                                <td><?= htmlspecialchars($cost['cost_allocation']) ?></td>
                                <td style="text-align: right;"><?= number_format($cost['cost'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr class="total-row">
                            <td>Total Estimated Cost</td>
                            <td style="text-align: right;">₱<?= number_format($request['estimated_cost'], 2) ?></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No cost breakdown available</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="section">
            <div class="section-title">Request Status</div>
            <div class="field-group">
                <div class="field-label">Status:</div>
                <div class="field-value">
                    <span class="status-badge status-<?= strtolower($request['status']) ?>">
                        <?= htmlspecialchars($request['status']) ?>
                    </span>
                    <?php if ($request['status'] == 'Rejected' && !empty($request['rejection_reason'])): ?>
                        <div style="margin-top: 10px; padding: 10px; background: #fff3cd; border-left: 3px solid #ffc107;">
                            <strong>Reason:</strong> <?= htmlspecialchars($request['rejection_reason']) ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="footer">
            <p><strong>Travel Request System</strong></p>
            <p>Generated on <?= date('F d, Y h:i A') ?></p>
            <p>© <?= date('Y') ?> Travel Request System. All rights reserved.</p>
        </div>
    </div>

    <script>
        // Auto-print when page loads (optional - remove if you want manual print only)
        window.onload = function() {
            // Uncomment the line below if you want automatic printing
            // window.print();
        };
    </script>
</body>
</html>