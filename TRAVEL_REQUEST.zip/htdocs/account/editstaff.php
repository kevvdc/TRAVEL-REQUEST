<?php 
require_once "../classes/staff.php";
session_start();


if (!isset($_SESSION["user"])) {
    header("Location: ../account/login.php");
    exit();
}

if (!isset($_SESSION["user"]) || !isset($_SESSION["user"]["role"]) || strcasecmp($_SESSION["user"]["role"], "Admin") !== 0) {
    echo "Access Denied.";
    exit();
}



$staffObj = new Staff();

$staff = [
    "firstname" => "",
    "lastname" => "",
    "email" => "",
    "role" => "",
    "is_active" => 1
];

$errors = [
    "firstname" => "",
    "lastname" => "",
    "email" => "",
    "role" => ""
];

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET["id"])) {
        $id = trim(htmlspecialchars($_GET["id"]));
        $existing = $staffObj->fetchStaff($id);

        if ($existing) {
            $staff["firstname"] = $existing["firstname"];
            $staff["lastname"] = $existing["lastname"];
            $staff["email"] = $existing["email"];
            $staff["role"] = $existing["role"];
            $staff["is_active"] = $existing["is_active"];
        } else {
            echo "<a href='list.php'>Back to Staff List</a>";
            exit("Staff Not Found");
        }
    } else {
        echo "<a href='list.php'>Back to Staff List</a>";
        exit("Invalid Request");
    }
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_GET["id"];

    $staff["firstname"] = trim(htmlspecialchars($_POST["firstname"]));
    $staff["lastname"] = trim(htmlspecialchars($_POST["lastname"]));
    $staff["email"] = trim(htmlspecialchars($_POST["email"]));
    $staff["role"] = trim($_POST["role"]);
    $staff["is_active"] = isset($_POST["is_active"]) ? 1 : 0;

    if (empty($staff["firstname"]))
        $errors["firstname"] = "Firstname is required.";

    if (empty($staff["lastname"]))
        $errors["lastname"] = "Lastname is required.";

    if (empty($staff["email"]))
        $errors["email"] = "Email is required.";
    elseif (!filter_var($staff["email"], FILTER_VALIDATE_EMAIL))
        $errors["email"] = "Invalid email format.";

    if (empty($staff["role"]))
        $errors["role"] = "Role is required.";

    if (empty(array_filter($errors))) {
        $staffObj->firstname = $staff["firstname"];
        $staffObj->lastname = $staff["lastname"];
        $staffObj->email = $staff["email"];
        $staffObj->role = $staff["role"];
        $staffObj->is_active = $staff["is_active"];

        if ($staffObj->editStaff($id)) {
            header("Location: list.php");
            exit();
        } else {
            echo "An error occurred while updating the staff.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Staff</title>
    <link rel="stylesheet" href="styles/form.css">
    <style>
        span, .error { color: #b11226; }
    </style>
</head>
<body>
    <div class="form-card">
        <h1>Edit Staff</h1>
        <label>Fields with <span>*</span> are required</label>

        <form action="" method="post">
            <label>Firstname <span>*</span></label>
            <input type="text" name="firstname" value="<?= htmlspecialchars($staff['firstname']) ?>">
            <p class="error"><?= $errors['firstname'] ?></p>

            <label>Lastname <span>*</span></label>
            <input type="text" name="lastname" value="<?= htmlspecialchars($staff['lastname']) ?>">
            <p class="error"><?= $errors['lastname'] ?></p>

            <label>Email <span>*</span></label>
            <input type="email" name="email" value="<?= htmlspecialchars($staff['email']) ?>">
            <p class="error"><?= $errors['email'] ?></p>

            <label>Role <span>*</span></label>
            <select name="role">
                <option value="">--Select Role--</option>
                <option value="Admin" <?= ($staff['role'] == 'Admin') ? 'selected' : '' ?>>Admin</option>
                <option value="Staff" <?= ($staff['role'] == 'Staff') ? 'selected' : '' ?>>Staff</option>
            </select>
            <p class="error"><?= $errors['role'] ?></p>

            <label>
                <input type="checkbox" name="is_active" <?= ($staff['is_active']) ? 'checked' : '' ?>>
                Active
            </label>

            <br>
            <input type="submit" value="Update Staff">
        </form>
    </div>

    <div class="button-container">
        <button><a href="list.php">Back to List</a></button> | 
        <button><a href="../account/logout.php">Logout</a></button>
    </div>
</body>
</html>
