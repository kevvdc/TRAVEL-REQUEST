<?php 
require_once "../classes/staff.php";
session_start();

// Redirect if user is not logged in
if (!isset($_SESSION["user"])) {
    header("Location: ../account/login.php");
    exit();
}

// Check user role (case-insensitive)
if (!isset($_SESSION["user"]["role"]) || strtolower($_SESSION["user"]["role"]) !== "admin") {
    echo "Access Denied.";
    exit();
}

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $staffObj = new Staff();

    if ($staffObj->deleteStaff($id)) {
        header("Location: list.php");
        exit();
    } else {
        echo "Failed to delete staff.";
    }
} else {
    echo "<a href='list.php'>Back to Staff List</a>";
    exit("Invalid Request");
}
?>
