<?php

// SMTP SERVER SETTINGS
define("SMTP_HOST", "smtp.gmail.com");      // Example Gmail SMTP
define("SMTP_USERNAME", "delacruzitelective@gmail.com");
define("SMTP_PASSWORD", "your_app_password");
define("SMTP_PORT", 587);

// EMAIL SENDER INFO
define("SMTP_FROM_EMAIL", "yourgmail@gmail.com");
define("SMTP_FROM_NAME", "Your System");

// WEBSITE URL
define("BASE_URL", "http://localhost/your_project_folder");

?>
