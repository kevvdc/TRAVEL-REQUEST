<?php
session_start();

// ------------------------------
// Admin Access Check
// ------------------------------
if (!isset($_SESSION['user']['role']) || strcasecmp($_SESSION['user']['role'], 'Admin') !== 0) {
    header('Location: login.php');
   exit();
}

// ------------------------------
// Required Classes
// ------------------------------
require_once "../classes/staff.php";
require_once "../classes/email_verification.php";

$staffObj = new Staff();
$emailVerifier = new EmailVerification();

$staff = [];
$errors = [];

// ------------------------------
// Handle Form Submission
// ------------------------------
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $staff["firstname"] = trim(htmlspecialchars($_POST["firstname"] ?? ""));
    $staff["lastname"] = trim(htmlspecialchars($_POST["lastname"] ?? ""));
    $staff["role"] = trim(htmlspecialchars($_POST["role"] ?? ""));
    $staff["email"] = trim(htmlspecialchars($_POST["email"] ?? ""));
    $staff["password"] = trim(htmlspecialchars($_POST["password"] ?? ""));

    // Validation
    if (!$staff["firstname"]) $errors["firstname"] = "Firstname is required";
    if (!$staff["lastname"]) $errors["lastname"] = "Lastname is required";
    if (!$staff["role"]) $errors["role"] = "Please select a role";
    if (!$staff["email"]) $errors["email"] = "Email is required";
    if (!$staff["password"]) $errors["password"] = "Password is required";

    // Check if email already exists
    if (empty($errors["email"])) {
        $conn = $staffObj->connect();
        $stmt = $conn->prepare("SELECT COUNT(*) FROM staff WHERE email = :email");
        $stmt->execute([':email' => $staff["email"]]);
        if ($stmt->fetchColumn() > 0) {
            $errors["email"] = "Email already exists";
        }
    }

    // If no errors, send verification email and store data in session ONLY
    if (empty($errors)) {
        try {
            $pinCode = ""; // Will be generated inside verifyEmail by reference
            $emailVerifier->verifyEmail(
                $staff["email"],
                $staff["firstname"] . " " . $staff["lastname"],
                $pinCode
            );
            
            // Store staff data in SESSION ONLY - DO NOT add to database yet
            $_SESSION['pending_staff'] = [
                'firstname' => $staff["firstname"],
                'lastname' => $staff["lastname"],
                'role' => $staff["role"],
                'email' => $staff["email"],
                'password' => $staff["password"],
                'pin_code' => $pinCode,
                'pin_expiry' => date('Y-m-d H:i:s', strtotime('+10 minutes'))
            ];
            
            // Set verification session for verify_pin.php
            $_SESSION['verification'] = true;
            $_SESSION['email'] = $staff["email"];
            $_SESSION['pin_code'] = $pinCode;
            $_SESSION['pin_expiry'] = date('Y-m-d H:i:s', strtotime('+10 minutes'));

            // Redirect to verification page
            header("Location: verify_pin.php");
            exit();
            
        } catch (Exception $e) {
            $errors["email"] = "Failed to send verification email: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Staff</title>
    <link rel="stylesheet" href="styles/form.css">
    <style>
        label { display: block; }
        span { color: red; }
        p.error { color: red; margin: 0; }

        /* Loading Overlay */
        .loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            background: rgba(0, 0, 0, 0.7);
            z-index: 99999;
            overflow: hidden;
        }
        .loading-overlay.active {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
        }
        .loading-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            margin: auto;
        }
        .loading-spinner {
            border: 8px solid #f3f3f3;
            border-top: 8px solid #3498db;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        .loading-text {
            color: white;
            font-size: 18px;
            margin-top: 20px;
            text-align: center;
            padding: 0 20px;
            max-width: 90vw;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

    </style>
</head>
<body>
    <div class="form-card">
        <h1>Register Staff</h1>
        <label>Fields with <span>*</span> are required</label>

        <?php if (!empty($errors["general"])): ?>
            <p class="error"><?= $errors["general"] ?></p>
        <?php endif; ?>

        <form method="POST">
            <label for="firstname">Firstname <span>*</span></label>
            <input type="text" name="firstname" id="firstname" value="<?= $staff["firstname"] ?? "" ?>">
            <p class="error"><?= $errors["firstname"] ?? "" ?></p>

            <label for="lastname">Lastname <span>*</span></label>
            <input type="text" name="lastname" id="lastname" value="<?= $staff["lastname"] ?? "" ?>">
            <p class="error"><?= $errors["lastname"] ?? "" ?></p>

            <label for="role">Role <span>*</span></label>
            <select name="role" id="role">
                <option value="">--Select--</option>
                <option value="Staff" <?= ($staff["role"] ?? "") == "Staff" ? "selected" : "" ?>>Staff</option>
                <option value="Admin" <?= ($staff["role"] ?? "") == "Admin" ? "selected" : "" ?>>Admin</option>
            </select>
            <p class="error"><?= $errors["role"] ?? "" ?></p>

            <label for="email">Email <span>*</span></label>
            <input type="email" name="email" id="email" value="<?= $staff["email"] ?? "" ?>">
            <p class="error"><?= $errors["email"] ?? "" ?></p>

            <label for="password">Password <span>*</span></label>
            <input type="password" name="password" id="password">
            <p class="error"><?= $errors["password"] ?? "" ?></p>

            <br>
            <input type="submit" value="Register Staff">
        </form>
    </div>

    <div class="button-container">
        <button><a href="list.php">Back to List</a></button> |
        <button><a href="logout.php">Logout</a></button>
    </div>

    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div style="text-align: center;">
            <div class="loading-spinner"></div>
            <div class="loading-text">Sending verification email...<br>Please wait...</div>
        </div>
    </div>

     <script>
        // Show loading overlay when form is submitted
        document.querySelector('form').addEventListener('submit', function(e) {
            // Show loading immediately when Register Staff button is clicked
            document.getElementById('loadingOverlay').classList.add('active');
        });
    </script>
    </body>

</body>
</html>