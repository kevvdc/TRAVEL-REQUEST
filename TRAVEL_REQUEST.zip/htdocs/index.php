<?php
// Redirect to the login page
header("Location: account/login.php");
exit();
?>