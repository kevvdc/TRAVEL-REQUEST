<?php

require_once "databases.php";

class TravelRequest extends Database
{
    public $staff_id = "";
    public $admin_reject_id = null;
    public $destination_venue = "";
    public $destination_city = "";
    public $destination_country = "";
    public $travel_start_date = "";
    public $travel_end_date = "";
    public $purpose = "";
    public $estimated_cost = 0.00;
    public $status = "Pending";
    public $rejection_reason = null;

    /* ============================================================
       CREATE NOTIFICATION
       ============================================================ */
    private function createNotification($user_id, $request_id, $type, $message)
    {
        $sql = "INSERT INTO notifications (user_id, request_id, type, message, created_at)
                VALUES (:user_id, :request_id, :type, :message, NOW())";
        $query = $this->connect()->prepare($sql);
        return $query->execute([
            ":user_id" => $user_id,
            ":request_id" => $request_id,
            ":type" => $type,
            ":message" => $message
        ]);
    }

    /* ============================================================
       ADD REQUEST + COSTS + NOTIFY ADMIN
       ============================================================ */
    public function addRequest($allocations = [], $costs = [])
    {
        $conn = $this->connect();
        $sql = "INSERT INTO travelrequests 
                (staff_id, destination_venue, destination_city, destination_country, travel_start_date, travel_end_date, purpose, estimated_cost, status)
                VALUES 
                (:staff_id, :venue, :city, :country, :start_date, :end_date, :purpose, :estimated_cost, :status)";
        $query = $conn->prepare($sql);
        $query->bindParam(":staff_id", $this->staff_id);
        $query->bindParam(":venue", $this->destination_venue);
        $query->bindParam(":city", $this->destination_city);
        $query->bindParam(":country", $this->destination_country);
        $query->bindParam(":start_date", $this->travel_start_date);
        $query->bindParam(":end_date", $this->travel_end_date);
        $query->bindParam(":purpose", $this->purpose);
        $query->bindParam(":estimated_cost", $this->estimated_cost);
        $query->bindParam(":status", $this->status);

        if ($query->execute()) {
            $request_id = $conn->lastInsertId();

            /* Insert costs */
            if (!empty($allocations) && !empty($costs)) {
                $cost_sql = "INSERT INTO costs (request_id, cost_allocation, cost) 
                             VALUES (:request_id, :allocation, :cost)";
                $cost_query = $conn->prepare($cost_sql);

                for ($i = 0; $i < count($allocations); $i++) {
                    if (!empty($allocations[$i]) && is_numeric($costs[$i])) {
                        $cost_query->execute([
                            ":request_id" => $request_id,
                            ":allocation" => $allocations[$i],
                            ":cost" => $costs[$i]
                        ]);
                    }
                }
            }

            /* Notify Admin(s) */
            $admin_sql = "SELECT id FROM staff WHERE role = 'Admin'";
            $admins = $conn->query($admin_sql)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($admins as $admin) {
                $this->createNotification(
                    $admin['id'],
                    $request_id,
                    "NEW_REQUEST",
                    "A new travel request was submitted."
                );
            }

            return $request_id; 
        }

        return false;
    }

    /* ============================================================
       EDIT REQUEST + UPDATE COSTS + NOTIFY ADMIN
       ============================================================ */
    public function editRequest($request_id, $allocations = [], $costs = [])
    {
        $conn = $this->connect();
        
        // Fetch existing request to check status and for notifications
        $existing = $this->fetchRequest($request_id);
        if (!$existing) return false;

        $sql = "UPDATE travelrequests 
                SET destination_venue = :venue,
                    destination_city = :city,
                    destination_country = :country,
                    travel_start_date = :start_date,
                    travel_end_date = :end_date,
                    purpose = :purpose,
                    estimated_cost = :estimated_cost
                WHERE request_id = :request_id";
        
        $query = $conn->prepare($sql);
        $query->bindParam(":venue", $this->destination_venue);
        $query->bindParam(":city", $this->destination_city);
        $query->bindParam(":country", $this->destination_country);
        $query->bindParam(":start_date", $this->travel_start_date);
        $query->bindParam(":end_date", $this->travel_end_date);
        $query->bindParam(":purpose", $this->purpose);
        $query->bindParam(":estimated_cost", $this->estimated_cost);
        $query->bindParam(":request_id", $request_id);

        if ($query->execute()) {
            // Delete existing costs and insert new ones
            $this->deleteCosts($request_id);

            if (!empty($allocations) && !empty($costs)) {
                $cost_sql = "INSERT INTO costs (request_id, cost_allocation, cost) 
                             VALUES (:request_id, :allocation, :cost)";
                $cost_query = $conn->prepare($cost_sql);

                for ($i = 0; $i < count($allocations); $i++) {
                    if (!empty($allocations[$i]) && is_numeric($costs[$i])) {
                        $cost_query->execute([
                            ":request_id" => $request_id,
                            ":allocation" => $allocations[$i],
                            ":cost" => $costs[$i]
                        ]);
                    }
                }
            }

            // Notify Admin(s) about the update
            $admin_sql = "SELECT id FROM staff WHERE role = 'Admin'";
            $admins = $conn->query($admin_sql)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($admins as $admin) {
                $this->createNotification(
                    $admin['id'],
                    $request_id,
                    "REQUEST_UPDATED",
                    "Travel request to " . $this->destination_venue . " has been updated."
                );
            }

            return true;
        }

        return false;
    }

    /* ============================================================
       ADD COST
       ============================================================ */
    public function addCost($request_id, $allocation, $cost)
    {
        $sql = "INSERT INTO costs (request_id, cost_allocation, cost) 
                VALUES (:request_id, :allocation, :cost)";
        $query = $this->connect()->prepare($sql);
        $query->bindParam(":request_id", $request_id);
        $query->bindParam(":allocation", $allocation);
        $query->bindParam(":cost", $cost);
        return $query->execute();
    }

    public function getCosts($request_id)
    {
        $sql = "SELECT * FROM costs WHERE request_id = :request_id";
        $query = $this->connect()->prepare($sql);
        $query->bindParam(":request_id", $request_id);
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function deleteCosts($request_id)
    {
        $sql = "DELETE FROM costs WHERE request_id = :request_id";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(':request_id', $request_id);
        return $stmt->execute();
    }

    /* ============================================================
       VIEW REQUESTS
       ============================================================ */
    public function viewRequests($staff_id = null, $status = null)
    {
        $sql = "SELECT tr.*, s.firstname, s.lastname, a.firstname AS admin_firstname, a.lastname AS admin_lastname
                FROM travelrequests tr
                LEFT JOIN staff s ON tr.staff_id = s.id
                LEFT JOIN staff a ON tr.admin_reject_id = a.id
                WHERE 1=1";

        $params = [];
        if ($staff_id !== null) {
            $sql .= " AND tr.staff_id = :staff_id";
            $params[':staff_id'] = $staff_id;
        }

        if (!empty($status)) {
            $sql .= " AND tr.status = :status";
            $params[':status'] = $status;
        }

        $sql .= " ORDER BY tr.submitted_at DESC";

        $query = $this->connect()->prepare($sql);
        return $query->execute($params) ? $query->fetchAll(PDO::FETCH_ASSOC) : [];
    }

    public function fetchRequest($id)
    {
        $sql = "SELECT tr.*, s.firstname, s.lastname, a.firstname AS admin_firstname, a.lastname AS admin_lastname
                FROM travelrequests tr
                LEFT JOIN staff s ON tr.staff_id = s.id
                LEFT JOIN staff a ON tr.admin_reject_id = a.id
                WHERE tr.request_id = :id";
        $query = $this->connect()->prepare($sql);
        $query->bindParam(":id", $id);
        $query->execute();
        return $query->fetch(PDO::FETCH_ASSOC);
    }

    /* ============================================================
       APPROVE REQUEST
       - updates status and notifies staff
       ============================================================ */
    public function approveRequest($id, $admin_id = null)
    {
        $conn = $this->connect();

        // get request to find staff_id and current status
        $req = $this->fetchRequest($id);
        if (!$req) return false;

        $old_status = $req['status'];
        $staff_id = $req['staff_id'];

        $sql = "UPDATE travelrequests 
                SET status = 'Approved', admin_reject_id = NULL, rejection_reason = NULL
                WHERE request_id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":id", $id);
        $result = $stmt->execute();

        if ($result && $staff_id && $old_status !== "Approved") {
            $message = "Your travel request to " . $req['destination_venue'] . " has been approved.";
            $this->createNotification($staff_id, $id, "STATUS_UPDATE", $message);
        }

        return $result;
    }

    /* ============================================================
       REJECT REQUEST
       - updates status, sets admin id + reason, notifies staff
       ============================================================ */
    public function rejectRequest($id, $admin_id = null, $reason = "")
    {
        $conn = $this->connect();
        $req = $this->fetchRequest($id);
        if (!$req) return false;

        $old_status = $req['status'];
        $staff_id = $req['staff_id'];

        $sql = "UPDATE travelrequests 
                SET status = 'Rejected', admin_reject_id = :admin_id, rejection_reason = :reason
                WHERE request_id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":admin_id", $admin_id);
        $stmt->bindParam(":reason", $reason);
        $stmt->bindParam(":id", $id);

        $result = $stmt->execute();
        if ($result && $staff_id && $old_status !== "Rejected") {
            $message = "Your travel request to " . $req['destination_venue'] . " has been rejected.";
            if (!empty($reason)) $message .= " Reason: " . $reason;
            $this->createNotification($staff_id, $id, "STATUS_UPDATE", $message);
        }

        return $result;
    }

    /* ============================================================
       UNDO -> set back to Pending and notify staff
       ============================================================ */
    public function undoRequest($id, $admin_id = null)
    {
        $conn = $this->connect();
        $req = $this->fetchRequest($id);
        if (!$req) return false;

        $old_status = $req['status'];
        $staff_id = $req['staff_id'];

        $sql = "UPDATE travelrequests 
                SET status = 'Pending', admin_reject_id = NULL, rejection_reason = NULL
                WHERE request_id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":id", $id);
        $result = $stmt->execute();

        if ($result && $staff_id && $old_status !== "Pending") {
            $message = "Your travel request to " . $req['destination_venue'] . " has been set back to Pending.";
            $this->createNotification($staff_id, $id, "STATUS_UPDATE", $message);
        }

        return $result;
    }

    /* ============================================================
       DELETE REQUEST
       - notifies staff (if possible) then deletes costs + request
       ============================================================ */
    public function deleteRequest($id, $admin_id = null)
    {
        $conn = $this->connect();
        $req = $this->fetchRequest($id);
        if (!$req) return false;

        $staff_id = $req['staff_id'];
        $status = $req['status'];

        // If we want to notify staff for deletions (particularly when request was rejected)
        if ($staff_id) {
            $message = "Your travel request to " . $req['destination_venue'] . " has been deleted by an administrator.";
            // Optionally mention if it was rejected before deletion
            if ($status === "Rejected" && !empty($req['rejection_reason'])) {
                $message .= " (Previously rejected. Reason: " . $req['rejection_reason'] . ")";
            }
            $this->createNotification($staff_id, $id, "STATUS_UPDATE", $message);
        }

        // Delete costs first
        $this->deleteCosts($id);

        // Delete request
        $sql = "DELETE FROM travelrequests WHERE request_id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }

    /* ============================================================
       KPI
       ============================================================ */
    public function kpi_view($staff_id = null)
    {
        $conn = $this->connect();
        $sql = "SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) AS approved,
                    SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending,
                    SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) AS rejected
                FROM travelrequests
                WHERE 1=1";

        $params = [];
        if ($staff_id !== null) {
            $sql .= " AND staff_id = :staff_id";
            $params[':staff_id'] = $staff_id;
        }

        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return [
            'total' => (int)($result['total'] ?? 0),
            'approved' => (int)($result['approved'] ?? 0),
            'pending' => (int)($result['pending'] ?? 0),
            'rejected' => (int)($result['rejected'] ?? 0),
        ];
    }

    /* ============================================================
       NOTIFICATIONS
       ============================================================ */
    public function getStaffNotifications($staff_id)
    {
        $sql = "SELECT n.id, n.message, n.created_at, tr.destination_venue, tr.status
                FROM notifications n
                LEFT JOIN travelrequests tr ON tr.request_id = n.request_id
                WHERE n.user_id = :staff_id
                ORDER BY n.created_at DESC";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(":staff_id", $staff_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAdminNotifications()
    {
        $sql = "SELECT n.id, n.message, n.created_at, tr.destination_venue, tr.submitted_at, s.firstname, s.lastname
                FROM notifications n
                LEFT JOIN travelrequests tr ON tr.request_id = n.request_id
                LEFT JOIN staff s ON s.id = tr.staff_id
                WHERE n.type = 'NEW_REQUEST'
                ORDER BY n.created_at DESC";
        return $this->connect()->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function deleteNotification($notif_id)
    {
        $sql = "DELETE FROM notifications WHERE id = :id";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(":id", $notif_id);
        return $stmt->execute();
    }
}
?>