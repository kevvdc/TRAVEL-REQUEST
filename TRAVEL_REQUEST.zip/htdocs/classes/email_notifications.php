<?php

require_once __DIR__ . "/../vendor/autoload.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class EmailNotifications
{
    private $fromEmail = 'kevindelacruz1526@gmail.com';
    private $fromName = 'Travel Request System';
    
    // Email template for staff notification (status update)
    public function getStatusUpdateEmailBody($staffName, $destination, $status, $rejectionReason = null) 
    {
        $statusColor = ($status === 'Approved') ? '#28a745' : '#dc3545';
        $statusIcon = ($status === 'Approved') ? '✓' : '✗';
        
        $rejectionSection = '';
        if ($status === 'Rejected' && !empty($rejectionReason)) {
            $rejectionSection = "
            <div class='rejection-reason'>
                <div class='rejection-title'>Reason for Rejection:</div>
                <div class='rejection-text'>{$rejectionReason}</div>
            </div>";
        }
        
        return "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }

                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f4f4f4;
                    padding: 20px;
                }

                .email-container {
                    max-width: 600px;
                    margin: 0 auto;
                    background: #ffffff;
                    border-radius: 10px;
                    overflow: hidden;
                    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
                }

                .header {
                    background: {$statusColor};
                    padding: 40px 20px;
                    text-align: center;
                    color: white;
                }

                .header h1 {
                    font-size: 24px;
                    margin-bottom: 8px;
                }

                .header p {
                    font-size: 14px;
                    opacity: 0.9;
                }

                .content {
                    padding: 40px 30px;
                }

                .greeting {
                    font-size: 18px;
                    color: #333;
                    margin-bottom: 15px;
                }

                .message {
                    font-size: 14px;
                    color: #555;
                    line-height: 1.6;
                    margin-bottom: 20px;
                }

                .status-container {
                    background: #f8f9fa;
                    border-left: 4px solid {$statusColor};
                    border-radius: 5px;
                    padding: 20px;
                    margin: 25px 0;
                }

                .status-label {
                    font-size: 12px;
                    color: #666;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                    margin-bottom: 8px;
                }

                .status-value {
                    font-size: 24px;
                    font-weight: bold;
                    color: {$statusColor};
                }

                .detail-row {
                    padding: 10px 0;
                    border-bottom: 1px solid #eee;
                }

                .detail-label {
                    font-weight: bold;
                    color: #333;
                    font-size: 13px;
                }

                .detail-value {
                    color: #666;
                    font-size: 14px;
                    margin-top: 5px;
                }

                .rejection-reason {
                    background: #fff3cd;
                    border-left: 4px solid #ffc107;
                    padding: 15px;
                    margin: 20px 0;
                    border-radius: 5px;
                }

                .rejection-title {
                    font-weight: bold;
                    color: #856404;
                    font-size: 14px;
                    margin-bottom: 8px;
                }

                .rejection-text {
                    color: #856404;
                    font-size: 13px;
                    line-height: 1.5;
                }

                .footer {
                    background: #fafafa;
                    padding: 20px;
                    border-top: 1px solid #ddd;
                    text-align: center;
                }

                .footer p {
                    font-size: 12px;
                    color: #999;
                    line-height: 1.5;
                }
            </style>
        </head>
        <body>
            <div class='email-container'>
                <div class='header'>
                    <div style='font-size: 48px; margin-bottom: 10px;'>{$statusIcon}</div>
                    <h1>Travel Request Update</h1>
                    <p>Status Notification</p>
                </div>

                <div class='content'>
                    <p class='greeting'>Hi <strong>{$staffName}</strong>,</p>

                    <p class='message'>
                        Your travel request has been updated. Please see the details below:
                    </p>

                    <div class='status-container'>
                        <div class='status-label'>Request Status</div>
                        <div class='status-value'>{$status}</div>
                    </div>

                    <div class='detail-row'>
                        <div class='detail-label'>Destination</div>
                        <div class='detail-value'>{$destination}</div>
                    </div>

                    {$rejectionSection}

                    <p class='message'>
                        Please log in to your account to view the complete details of your travel request.
                    </p>
                </div>

                <div class='footer'>
                    <p>
                        <strong>Travel Request System</strong><br>
                        This is an automated email – please do not reply.<br>
                        © 2025 Travel Request System. All rights reserved.
                    </p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
    
    // Email template for admin notification (new request)
    public function getNewRequestEmailBody($staffName, $destination, $startDate, $endDate, $purpose, $estimatedCost) 
    {
        return "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }

                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f4f4f4;
                    padding: 20px;
                }

                .email-container {
                    max-width: 600px;
                    margin: 0 auto;
                    background: #ffffff;
                    border-radius: 10px;
                    overflow: hidden;
                    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
                }

                .header {
                    background: #007bff;
                    padding: 40px 20px;
                    text-align: center;
                    color: white;
                }

                .header h1 {
                    font-size: 24px;
                    margin-bottom: 8px;
                }

                .header p {
                    font-size: 14px;
                    opacity: 0.9;
                }

                .content {
                    padding: 40px 30px;
                }

                .greeting {
                    font-size: 18px;
                    color: #333;
                    margin-bottom: 15px;
                }

                .message {
                    font-size: 14px;
                    color: #555;
                    line-height: 1.6;
                    margin-bottom: 20px;
                }

                .alert-box {
                    background: #e7f3ff;
                    border-left: 4px solid #007bff;
                    padding: 20px;
                    margin: 25px 0;
                    border-radius: 5px;
                }

                .alert-title {
                    font-weight: bold;
                    color: #004085;
                    font-size: 16px;
                    margin-bottom: 10px;
                }

                .detail-row {
                    padding: 10px 0;
                    border-bottom: 1px solid #eee;
                }

                .detail-label {
                    font-weight: bold;
                    color: #333;
                    font-size: 13px;
                }

                .detail-value {
                    color: #666;
                    font-size: 14px;
                    margin-top: 5px;
                }

                .cost-highlight {
                    background: #fff3cd;
                    padding: 15px;
                    border-radius: 5px;
                    margin: 15px 0;
                    text-align: center;
                }

                .cost-label {
                    font-size: 12px;
                    color: #856404;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                }

                .cost-value {
                    font-size: 28px;
                    font-weight: bold;
                    color: #856404;
                    margin-top: 5px;
                }

                .footer {
                    background: #fafafa;
                    padding: 20px;
                    border-top: 1px solid #ddd;
                    text-align: center;
                }

                .footer p {
                    font-size: 12px;
                    color: #999;
                    line-height: 1.5;
                }
            </style>
        </head>
        <body>
            <div class='email-container'>
                <div class='header'>
                    <div style='font-size: 48px; margin-bottom: 10px;'>📋</div>
                    <h1>New Travel Request</h1>
                    <p>Pending Admin Review</p>
                </div>

                <div class='content'>
                    <p class='greeting'>Hello Admin,</p>

                    <div class='alert-box'>
                        <div class='alert-title'>A new travel request has been submitted</div>
                    </div>

                    <div class='detail-row'>
                        <div class='detail-label'>Staff Member</div>
                        <div class='detail-value'>{$staffName}</div>
                    </div>

                    <div class='detail-row'>
                        <div class='detail-label'>Destination</div>
                        <div class='detail-value'>{$destination}</div>
                    </div>

                    <div class='detail-row'>
                        <div class='detail-label'>Travel Period</div>
                        <div class='detail-value'>{$startDate} to {$endDate}</div>
                    </div>

                    <div class='detail-row'>
                        <div class='detail-label'>Purpose</div>
                        <div class='detail-value'>{$purpose}</div>
                    </div>

                    <div class='cost-highlight'>
                        <div class='cost-label'>Estimated Cost</div>
                        <div class='cost-value'>₱" . number_format($estimatedCost, 2) . "</div>
                    </div>

                    <p class='message'>
                        Please log in to the admin panel to review and process this request.
                    </p>
                </div>

                <div class='footer'>
                    <p>
                        <strong>Travel Request System</strong><br>
                        This is an automated email – please do not reply.<br>
                        © 2025 Travel Request System. All rights reserved.
                    </p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
    
    // Send status update email to staff
    public function sendStatusUpdateEmail($toEmail, $staffName, $destination, $status, $rejectionReason = null)
    {
        try {
            $mail = new PHPMailer(true);

            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->fromEmail;
            $mail->Password   = 'auhe zwvf dhdo wbwx';
            $mail->SMTPSecure = 'ssl';
            $mail->Port       = 465;

            $mail->setFrom($this->fromEmail, $this->fromName);
            $mail->addAddress($toEmail, $staffName);

            $mail->isHTML(true);
            $mail->Subject = "Travel Request {$status} - Status Update";
            $mail->Body = $this->getStatusUpdateEmailBody($staffName, $destination, $status, $rejectionReason);
            $mail->AltBody = "Hello {$staffName}, Your travel request to {$destination} has been {$status}.";

            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log("Email send failed: {$mail->ErrorInfo}");
            return false;
        }
    }
    
    // Send new request email to admin
    public function sendNewRequestEmail($toEmail, $staffName, $destination, $startDate, $endDate, $purpose, $estimatedCost)
    {
        try {
            $mail = new PHPMailer(true);

            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->fromEmail;
            $mail->Password   = 'auhe zwvf dhdo wbwx';
            $mail->SMTPSecure = 'ssl';
            $mail->Port       = 465;

            $mail->setFrom($this->fromEmail, $this->fromName);
            $mail->addAddress($toEmail, 'Admin');

            $mail->isHTML(true);
            $mail->Subject = 'New Travel Request Submitted - Pending Review';
            $mail->Body = $this->getNewRequestEmailBody($staffName, $destination, $startDate, $endDate, $purpose, $estimatedCost);
            $mail->AltBody = "New travel request from {$staffName} to {$destination}. Estimated cost: ₱" . number_format($estimatedCost, 2);

            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log("Email send failed: {$mail->ErrorInfo}");
            return false;
        }
    }
}