<?php
require_once 'databases.php';

class Staff extends Database {
    public $id;
    public $firstname;
    public $lastname;
    public $role;
    public $email;
    public $password;

    // By default do NOT activate until verified
    public $is_active = 0;

    public $is_verified = 0;
    public $verification_token;

    // =============================
    // ADD STAFF WITH VERIFICATION
    // =============================
    public function addStaff() {

        // Generate token if not set
        if (empty($this->verification_token)) {
            $this->verification_token = bin2hex(random_bytes(32));
        }

        $sql = $sql = "INSERT INTO staff (firstname, lastname, role, email, password, is_active)
        VALUES (:firstname, :lastname, :role, :email, :password, :is_active)";


        $query = $this->connect()->prepare($sql);

        $query->bindParam(':firstname', $this->firstname);
        $query->bindParam(':lastname', $this->lastname);
        $query->bindParam(':role', $this->role);
        $query->bindParam(':email', $this->email);

        // Hash password
        $hashedPassword = password_hash($this->password, PASSWORD_DEFAULT);
        $query->bindParam(':password', $hashedPassword);

        // NOT ACTIVE UNTIL VERIFIED
        $query->bindParam(':is_active', $this->is_active, PDO::PARAM_INT);

        return $query->execute();
    }

    // =============================
    // GET STAFF BY EMAIL
    // =============================
    public function getStaffByEmail() {
        $sql = "SELECT * FROM staff WHERE email = :email LIMIT 1";
        $query = $this->connect()->prepare($sql);
        $query->bindParam(':email', $this->email);
        $query->execute();
        return $query->fetch(PDO::FETCH_ASSOC);
    }

    // =============================
    // VERIFY ACCOUNT
    // =============================
    public function verifyAccount($token) {
        $sql = "UPDATE staff 
                SET is_verified = 1, is_active = 1, verification_token = NULL
                WHERE verification_token = :token LIMIT 1";

        $query = $this->connect()->prepare($sql);
        $query->bindParam(':token', $token);
        return $query->execute();
    }

    // =============================
    // FETCH STAFF BY ID
    // =============================
    public function fetchStaff($id) {
        $sql = "SELECT * FROM staff WHERE id = :id LIMIT 1";
        $query = $this->connect()->prepare($sql);
        $query->bindParam(":id", $id, PDO::PARAM_INT);
        $query->execute();
        return $query->fetch(PDO::FETCH_ASSOC);
    }

    // =============================
    // EDIT STAFF
    // =============================
    public function editStaff($id) {
        $sql = "UPDATE staff 
                SET firstname = :firstname, 
                    lastname = :lastname, 
                    email = :email, 
                    role = :role, 
                    is_active = :is_active 
                WHERE id = :id";

        $query = $this->connect()->prepare($sql);

        $query->bindParam(":firstname", $this->firstname);
        $query->bindParam(":lastname", $this->lastname);
        $query->bindParam(":email", $this->email);
        $query->bindParam(":role", $this->role);
        $query->bindParam(":is_active", $this->is_active, PDO::PARAM_INT);
        $query->bindParam(":id", $id, PDO::PARAM_INT);

        return $query->execute();
    }

    // =============================
    // DELETE STAFF
    // =============================
    public function deleteStaff($id) {
        $sql = "DELETE FROM staff WHERE id = :id";
        $query = $this->connect()->prepare($sql);
        $query->bindParam(':id', $id, PDO::PARAM_INT);
        return $query->execute();
    }

    // =============================
    // VIEW STAFF
    // =============================
    public function viewStaff($name = "", $role = "") {
        $sql = "SELECT * FROM staff
                WHERE (firstname LIKE CONCAT('%', :name, '%')
                   OR lastname LIKE CONCAT('%', :name, '%')
                   OR email LIKE CONCAT('%', :name, '%'))
                AND role LIKE CONCAT('%', :role, '%')
                ORDER BY id ASC";

        $query = $this->connect()->prepare($sql);
        $query->bindParam(":name", $name);
        $query->bindParam(":role", $role);

        if ($query->execute())
            return $query->fetchAll(PDO::FETCH_ASSOC);
        return null;
    }
}
?>
