<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Adjust the path if you installed manually
require_once __DIR__ . '/../vendor/autoload.php'; // if using Composer
// require_once __DIR__ . '/phpmailer/src/Exception.php';
// require_once __DIR__ . '/phpmailer/src/PHPMailer.php';
// require_once __DIR__ . '/phpmailer/src/SMTP.php';

function sendVerificationEmail($toEmail, $code, $toName = '') {
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.example.com';  // Set your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'your_email@example.com'; // SMTP username
        $mail->Password   = 'your_password';          // SMTP password
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        //Recipients
        $mail->setFrom('your_email@example.com', 'Your Site Name');
        $mail->addAddress($toEmail, $toName);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Email Verification Code';
        $mail->Body    = "<p>Hello {$toName},</p>
                          <p>Your verification code is: <b>{$code}</b></p>
                          <p>Please enter this code to complete your registration.</p>";
        $mail->AltBody = "Hello {$toName},\nYour verification code is: {$code}";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Mail Error: {$mail->ErrorInfo}");
        return false;
    }
}
