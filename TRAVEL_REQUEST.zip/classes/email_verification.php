<?php

require_once __DIR__ . "/../vendor/autoload.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


class EmailVerification
{
    public function getPinEmailBody($recipientName, $pinCode) 
{
    return "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: #f4f4f4;
                padding: 20px;
            }

            .email-container {
                max-width: 600px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 10px;
                overflow: hidden;
                box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            }

            .header {
                background: #8B0000; /* Dark Crimson */
                padding: 40px 20px;
                text-align: center;
                color: white;
            }

            .header h1 {
                font-size: 24px;
                margin-bottom: 8px;
            }

            .header p {
                font-size: 14px;
                opacity: 0.9;
            }

            .content {
                padding: 40px 30px;
                text-align: center;
            }

            .greeting {
                font-size: 18px;
                color: #333;
                margin-bottom: 15px;
            }

            .message {
                font-size: 14px;
                color: #555;
                line-height: 1.6;
                margin-bottom: 30px;
            }

            .pin-container {
                background: #fff5f5;
                border: 2px dashed #A40000;
                border-radius: 10px;
                padding: 28px;
                margin: 25px 0;
            }

            .pin-label {
                font-size: 12px;
                color: #A40000;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 12px;
            }

            .pin-code {
                font-size: 48px;
                font-weight: bold;
                color: #8B0000;
                letter-spacing: 8px;
                font-family: 'Courier New', monospace;
            }

            .warning {
                background: #ffe8e8;
                border-left: 4px solid #cc0000;
                padding: 15px;
                margin: 20px 0;
                text-align: left;
            }

            .warning-title {
                font-weight: bold;
                color: #7a0000;
                font-size: 14px;
                margin-bottom: 5px;
            }

            .warning-text {
                color: #7a0000;
                font-size: 13px;
                line-height: 1.5;
            }

            .footer {
                background: #fafafa;
                padding: 20px;
                border-top: 1px solid #ddd;
                text-align: center;
            }

            .footer p {
                font-size: 12px;
                color: #999;
                line-height: 1.5;
            }
        </style>
    </head>
    <body>
        <div class='email-container'>
            <div class='header'>
                <div style='font-size: 48px; margin-bottom: 10px;'>🔐</div>
                <h1>Verification PIN</h1>
                <p>Travel Request System</p>
            </div>

            <div class='content'>
                <p class='greeting'>Hi <strong>{$recipientName}</strong>,</p>

                <p class='message'>
                    Your verification request has been received.  
                    Use the PIN below to continue and confirm your account access.
                </p>

                <div class='pin-container'>
                    <div class='pin-label'>Your One-Time PIN</div>
                    <div class='pin-code'>{$pinCode}</div>
                </div>

                <div class='warning'>
                    <div class='warning-title'>Important Reminder</div>
                    <div class='warning-text'>
                        • Keep your PIN private and secure<br>
                        • Our staff will never request your PIN<br>
                        • If this wasn’t you, simply disregard this message
                    </div>
                </div>

                <p class='message'>
                    If you need assistance, feel free to reach out to our support team anytime.
                </p>
            </div>

            <div class='footer'>
                <p>
                    <strong>Business Permits and Licensing Department</strong><br>
                    This is an automated email — please do not reply.<br>
                    © 2025 Business Permit System. All rights reserved.
                </p>
            </div>
        </div>
    </body>
    </html>
    ";
}

	
    public function verifyEmail($to_gmail, $full_name, &$pinCode)
    {
        // create a random pin to send to the gmail
        $pinCode = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // free host domain with 500 below limit sends
        $mail->SMTPAuth   = true;
        $mail->Username   = 'kevindelacruz1526@gmail.com';      // Your Gmail address
        $mail->Password   = 'auhe zwvf dhdo wbwx';          // App password (not regular password!)
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        // Recipients
        $mail->setFrom('kevindelacruz1526@gmail.com', 'Travel-Request');
        $mail->addAddress($to_gmail, $full_name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $mail->Body = $this->getPinEmailBody($full_name, $pinCode);
        $mail->AltBody = "Hello {$full_name}, Your verification PIN is: {$pinCode}";

        $mail->send();
    }
}