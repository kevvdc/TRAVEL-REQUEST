<?php
session_start();

if (!isset($_SESSION['user']) || !is_array($_SESSION['user'])) {
    header('Location: account/login.php');
    exit();
}

require_once "classes/travelrequest.php";

$user = $_SESSION['user'];
$firstname = $user['firstname'];
$lastname = $user['lastname'];

$travelRequest = new TravelRequest();

// ADMIN sees ALL staff requests
$kpi = $travelRequest->kpi_view(null);

$total = $kpi['total'] ?? 0;
$approved = $kpi['approved'] ?? 0;
$pending = $kpi['pending'] ?? 0;
$rejected = $kpi['rejected'] ?? 0;

$approvedPct = $total ? round(($approved / $total) * 100) : 0;
$pendingPct = $total ? round(($pending / $total) * 100) : 0;
$rejectedPct = $total ? round(($rejected / $total) * 100) : 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>

<h3 class="role-title">Admin Dashboard</h3>

<div class="container">
    <div class="dashboard-box">
        <!-- Header Section -->
        <div class="dashboard-header">
            <h1>TRAVEL REQUEST SYSTEM</h1>
            <h2>Welcome, <?= htmlspecialchars($firstname) ?> <?= htmlspecialchars($lastname) ?></h2>
        </div>

        <!-- Main Content: Landscape Split -->
        <div class="dashboard-content">
            <!-- LEFT SIDE: KPI and Graphs -->
            <div class="kpi-section">
                <h3>All Employees Total Requests</h3>

                <div class="kpi-cards">
                    <div class="kpi-box total"><h4>Total</h4><p><?= $total ?></p></div>
                    <div class="kpi-box approved"><h4>Approved</h4><p><?= $approved ?></p></div>
                    <div class="kpi-box pending"><h4>Pending</h4><p><?= $pending ?></p></div>
                    <div class="kpi-box rejected"><h4>Rejected</h4><p><?= $rejected ?></p></div>
                </div>

                <h3>Request Status Overview</h3>
                <div class="bar-report">
                    <div class="bar-item">
                        <span>Approved (<?= $approvedPct ?>%)</span>
                        <div class="bar approved" style="width: <?= $approvedPct ?>%"></div>
                    </div>
                    <div class="bar-item">
                        <span>Pending (<?= $pendingPct ?>%)</span>
                        <div class="bar pending" style="width: <?= $pendingPct ?>%"></div>
                    </div>
                    <div class="bar-item">
                        <span>Rejected (<?= $rejectedPct ?>%)</span>
                        <div class="bar rejected" style="width: <?= $rejectedPct ?>%"></div>
                    </div>
                </div>
            </div>

            <!-- RIGHT SIDE: Menu Options -->
            <div class="dashboard-menu">
                <a href="./request/apprejreq.php" class="btn">Manage All Requests</a>
                <a href="./account/list.php" class="btn">Manage Staff</a>
                <a href="./request/notifications/notifications_admin.php" class="btn">Notifications</a>
                <a href="account/logout.php" class="btn logout">Logout</a>
            </div>
        </div>
    </div>
</div>

</body>
</html>